#!/bin/bash
set -e

is_pip=`yum list installed | grep python2-pip | wc -l`
current_dir=`pwd`
is_setuptools=`pip list | grep setuptools | wc -l`
is_python2=`which python2 | grep python2 | wc -l`

if [[ $is_python2 -eq 0 ]];
then
    echo "please install Python version 2"
    exit 1
fi

if [[ $is_pip -eq 0 ]];
then
    echo "intall python2-pip"
    yum install -y python2-pip
fi

if [[ $is_setuptools -eq 0 ]];
then
    pip install ./packages/setuptools*
fi

pip install --no-index --find-links="file://$current_dir/packages" -r ./requirements.pip
pip install ./pypiserver-1.2.1.zip
